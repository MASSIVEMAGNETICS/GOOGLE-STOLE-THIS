import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI, GenerateContentResponse, Modality, Type } from "@google/genai";

interface SessionGalleryItem {
    src: string;
    blendMode: string | null;
    date: Date;
    name: string;
    tags: string[];
    type: 'blend' | 'swap' | 'inpaint';
    aspectRatio: string;
}

const App = () => {
    const [activeTab, setActiveTab] = useState<'blend' | 'swap' | 'inpaint'>('blend');
    
    // State for Image Blending
    const [images, setImages] = useState<(string | null)[]>([null, null]);
    const [blendMode, setBlendMode] = useState<string>('');
    const [prompt, setPrompt] = useState<string>('');
    const [selectedModel, setSelectedModel] = useState<string>('imagen-4.0-generate-001');
    const [aspectRatio, setAspectRatio] = useState<string>('1:1');
    const [numberOfImages, setNumberOfImages] = useState(1);
    
    // State for Face Swap
    const [sourceImage, setSourceImage] = useState<string | null>(null);
    const [faceRefImage, setFaceRefImage] = useState<string | null>(null);
    const [faceSwapPrompt, setFaceSwapPrompt] = useState<string>('');
    const [mask, setMask] = useState<string | null>(null);
    const [brushSize, setBrushSize] = useState(40);
    const [faceFidelity, setFaceFidelity] = useState(75);
    const [colorMatching, setColorMatching] = useState(75);

    // State for Inpainting
    const [inpaintImage, setInpaintImage] = useState<string | null>(null);
    const [inpaintMask, setInpaintMask] = useState<string | null>(null);
    const [inpaintPrompt, setInpaintPrompt] = useState<string>('');
    const [inpaintCreativity, setInpaintCreativity] = useState(50);

    // General State
    const [loading, setLoading] = useState<boolean>(false);
    const [loadingMessage, setLoadingMessage] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [generatedImages, setGeneratedImages] = useState<string[]>([]);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null); // The selected image
    const [generatedImageMetadata, setGeneratedImageMetadata] = useState<{name: string, tags: string[]} | null>(null);
    const [isMetadataLoading, setIsMetadataLoading] = useState<boolean>(false);
    const [sessionGallery, setSessionGallery] = useState<SessionGalleryItem[]>([]);
    const [galleryFilter, setGalleryFilter] = useState<string>('all');
    const [gallerySort, setGallerySort] = useState<'newest' | 'oldest'>('newest');

    const ai = useMemo(() => new GoogleGenAI({ apiKey: process.env.API_KEY }), []);

    const BLEND_MODES = [
        { name: 'Fusion', description: 'Smoothly merges concepts and aesthetics into a cohesive whole.' },
        { name: 'Surreal Collage', description: 'Creates a dreamlike composition with artistic juxtapositions.' },
        { name: 'Painterly Blend', description: 'Reimagines inputs with classical brushwork and texture.' },
        { name: 'Photorealistic Composite', description: 'Seamlessly integrates elements into a single, believable photograph.' },
        { name: 'Graphic Mashup', description: 'Bold, pop-art style with sharp lines and vibrant colors.' },
    ];
    
    const ASPECT_RATIOS = ["1:1", "16:9", "9:16", "4:3", "3:4"];

    const GENERATION_MODELS = [
        { id: 'imagen-4.0-generate-001', name: 'Imagen 4' },
    ];

    const handleGenerateMetadata = async () => {
        if (!generatedImage) return;

        setIsMetadataLoading(true);
        setError(null);
        try {
            const mimeType = generatedImage.split(';')[0].split(':')[1];
            const data = generatedImage.split(',')[1];
            
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: {
                    parts: [
                        { inlineData: { mimeType, data } },
                        { text: 'Analyze this image. Generate a creative, descriptive 3-word file name and 3-4 relevant metadata tags for searching. The name should be lowercase with words separated by hyphens.' }
                    ]
                },
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            name: { type: Type.STRING, description: 'A 3-word lowercase file name, e.g., "surreal-cat-portrait".' },
                            tags: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'An array of 3-4 string tags.' }
                        },
                        required: ['name', 'tags']
                    }
                }
            });
            const metadata = JSON.parse(response.text);
            setGeneratedImageMetadata(metadata);
        } catch (err) {
            console.error("Failed to generate metadata:", err);
            setError(err instanceof Error ? err.message : 'An unknown error occurred while generating metadata.');
            setGeneratedImageMetadata(null);
        } finally {
            setIsMetadataLoading(false);
        }
    };
    
    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const newImages = [...images];
                newImages[index] = reader.result as string;
                setImages(newImages);
            };
            reader.readAsDataURL(file);
        }
    };
    
     const handleSourceImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setSourceImage(reader.result as string);
                setMask(null); // Reset mask when new image is uploaded
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleFaceRefUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setFaceRefImage(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleInpaintImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setInpaintImage(reader.result as string);
                setInpaintMask(null);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleRemoveImage = (indexToRemove: number) => {
        const newImages = images.map((img, index) => index === indexToRemove ? null : img);
        setImages(newImages);
    };

    const handleAddImageSlot = () => {
        if (images.length < 5) {
            setImages([...images, null]);
        }
    };
    
    const handleReset = () => {
        if (activeTab === 'blend') {
            setImages([null, null]);
            setBlendMode('');
            setPrompt('');
            setAspectRatio('1:1');
            setNumberOfImages(1);
        } else if (activeTab === 'swap') {
            setSourceImage(null);
            setFaceRefImage(null);
            setFaceSwapPrompt('');
            setMask(null);
            setFaceFidelity(75);
            setColorMatching(75);
        } else if (activeTab === 'inpaint') {
            setInpaintImage(null);
            setInpaintMask(null);
            setInpaintPrompt('');
            setInpaintCreativity(50);
        }
        setGeneratedImage(null);
        setGeneratedImages([]);
        setGeneratedImageMetadata(null);
        setError(null);
        setLoading(false);
    };
    
    const handleSaveToSession = () => {
        if (generatedImage && generatedImageMetadata && !sessionGallery.some(item => item.src === generatedImage)) {
            const newItem: SessionGalleryItem = {
                src: generatedImage,
                name: generatedImageMetadata.name,
                tags: generatedImageMetadata.tags,
                date: new Date(),
                type: activeTab,
                blendMode: activeTab === 'blend' ? blendMode : null,
                aspectRatio: activeTab === 'blend' ? aspectRatio : '1:1',
            };
            setSessionGallery([newItem, ...sessionGallery]);
        }
    };

    const handleLoadToInpainting = (src: string) => {
        setActiveTab('inpaint');
        setInpaintImage(src);
        setInpaintMask(null);
        setInpaintPrompt('');
        setGeneratedImage(null);
        setGeneratedImages([]);
        setError(null);
    };

    const handleInpaintGenerate = async () => {
        if (!inpaintImage || !inpaintMask || !inpaintPrompt) {
            setError('Please provide an image, draw a mask, and enter a prompt.');
            return;
        }
        setLoading(true);
        setLoadingMessage('Performing inpainting magic...');
        setError(null);
        setGeneratedImage(null);
        setGeneratedImages([]);
        setGeneratedImageMetadata(null);

        try {
            const creativityPrompt = `Apply this with ${inpaintCreativity}% creativity, where 100% is maximum artistic freedom and 0% is a very literal interpretation.`;
            const fullPrompt = `You are a master digital artist specializing in photorealistic inpainting. Your task is to seamlessly edit an image based on a user's prompt and a mask. The first image is the source. The second image is the mask. You must edit the source image ONLY in the area indicated by the mask. Your edits should blend perfectly with the surrounding image, matching lighting, shadows, and texture. The user wants to: '${inpaintPrompt}'. ${creativityPrompt}`;

            const sourceImagePart = { inlineData: { mimeType: inpaintImage.split(';')[0].split(':')[1], data: inpaintImage.split(',')[1] } };
            const maskPart = { inlineData: { mimeType: 'image/png', data: inpaintMask.split(',')[1] } };

            const response: GenerateContentResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image-preview',
                contents: { parts: [sourceImagePart, maskPart, { text: fullPrompt }] },
                config: { responseModalities: [Modality.IMAGE, Modality.TEXT] },
            });

            const imagePart = response.candidates?.[0]?.content?.parts?.find(part => part.inlineData);

            if (imagePart?.inlineData) {
                const base64ImageBytes = imagePart.inlineData.data;
                const mimeType = imagePart.inlineData.mimeType;
                const newImage = `data:${mimeType};base64,${base64ImageBytes}`;
                setGeneratedImage(newImage);
                setGeneratedImages([newImage]);
            } else {
                throw new Error('Inpainting failed. The model did not return an image.');
            }
        } catch(err) {
            console.error(err);
            setError(err instanceof Error ? err.message : 'An unknown error occurred during inpainting.');
        } finally {
            setLoading(false);
            setLoadingMessage('');
        }
    };
    
    const handleFaceSwapGenerate = async () => {
        if (!sourceImage || !faceRefImage) {
            setError('Please upload a source image and a face to swap.');
            return;
        }

        setLoading(true);
        setLoadingMessage('Performing face swap...');
        setError(null);
        setGeneratedImage(null);
        setGeneratedImages([]);
        setGeneratedImageMetadata(null);
        
        try {
            const newPrompt = `You are an expert in digital image manipulation. Your task is to perform a photorealistic face swap. Replace the face in the first image (the source) with the face from the ${mask ? 'third' : 'second'} image (the reference face). ${mask ? 'The second image is a mask indicating the exact area on the source image where the swap should occur.' : ''} The final image must be seamless. Match the reference face features with ${faceFidelity}% fidelity. Adapt the lighting and skin tone to the source image with ${colorMatching}% intensity. Apply the user's guidance: '${faceSwapPrompt || 'Ensure the result is photorealistic and natural.'}'`;
            
            const sourceImagePart = { inlineData: { mimeType: sourceImage.split(';')[0].split(':')[1], data: sourceImage.split(',')[1] } };
            const faceRefPart = { inlineData: { mimeType: faceRefImage.split(';')[0].split(':')[1], data: faceRefImage.split(',')[1] } };
            
            const parts = [
                sourceImagePart,
                ...(mask ? [{ inlineData: { mimeType: 'image/png', data: mask.split(',')[1] } }] : []),
                faceRefPart,
                { text: newPrompt },
            ];

            const response: GenerateContentResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image-preview',
                contents: { parts },
                config: { responseModalities: [Modality.IMAGE, Modality.TEXT] },
            });
            
            const imagePart = response.candidates?.[0]?.content?.parts?.find(part => part.inlineData);

            if (imagePart?.inlineData) {
                const base64ImageBytes = imagePart.inlineData.data;
                const mimeType = imagePart.inlineData.mimeType;
                const newImage = `data:${mimeType};base64,${base64ImageBytes}`;
                setGeneratedImage(newImage);
                setGeneratedImages([newImage]);
            } else {
                throw new Error('Face swap generation failed. The model did not return an image.');
            }

        } catch(err) {
            console.error(err);
            setError(err instanceof Error ? err.message : 'An unknown error occurred during face swap generation.');
        } finally {
            setLoading(false);
            setLoadingMessage('');
        }
    };

    const handleBlendGenerate = async () => {
        const validImages = images.filter(img => img) as string[];
        if (validImages.length < 2 || !blendMode) {
            setError('Please upload at least two images and select a blend style.');
            return;
        }

        setLoading(true);
        setError(null);
        setGeneratedImage(null);
        setGeneratedImages([]);
        setGeneratedImageMetadata(null);

        try {
            setLoadingMessage('Generating creative prompt...');
            const visionPrompt = `As an expert art director, analyze the provided images. Create a single, detailed, and vivid prompt for an AI image generator. This new prompt must creatively combine the core subjects, styles, and concepts from all images, interpreted through the artistic lens of '${blendMode}'. Weave in the user's specific guidance: '${prompt || 'Create a visually stunning masterpiece.'}'. Your response must be ONLY the resulting creative prompt, ready to be used by an image generation model. Do not include any other text, conversation, or explanations.`;
            
            const imageParts = validImages.map(img => ({ inlineData: { mimeType: img.split(';')[0].split(':')[1], data: img.split(',')[1] } }));

            const visionResponse: GenerateContentResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: { parts: [...imageParts, { text: visionPrompt }] },
            });
            
            const descriptivePrompt = visionResponse.text;
            if (!descriptivePrompt) {
                throw new Error('Could not generate a descriptive prompt.');
            }
            
            setLoadingMessage(`Generating ${numberOfImages} image(s)...`);
            const imageResponse = await ai.models.generateImages({
                model: selectedModel,
                prompt: descriptivePrompt,
                config: {
                    numberOfImages: numberOfImages,
                    outputMimeType: 'image/jpeg',
                    aspectRatio: aspectRatio as "1:1" | "3:4" | "4:3" | "9:16" | "16:9",
                },
            });
            
            const newImages = imageResponse.generatedImages.map(img => `data:image/jpeg;base64,${img.image.imageBytes}`);

            if (newImages.length > 0) {
                setGeneratedImages(newImages);
                setGeneratedImage(newImages[0]);
            } else {
                throw new Error('Image generation failed. The response did not contain image data.');
            }

        } catch (err) {
            console.error(err);
            setError(err instanceof Error ? err.message : 'An unknown error occurred during image generation.');
        } finally {
            setLoading(false);
            setLoadingMessage('');
        }
    };

    const handleGenerate = async () => {
        switch (activeTab) {
            case 'blend':
                await handleBlendGenerate();
                break;
            case 'swap':
                await handleFaceSwapGenerate();
                break;
            case 'inpaint':
                await handleInpaintGenerate();
                break;
        }
    };

    const filteredAndSortedGallery = useMemo(() => {
        return sessionGallery
            .filter(item => galleryFilter === 'all' || item.type === galleryFilter)
            .sort((a, b) => {
                if (gallerySort === 'newest') {
                    return b.date.getTime() - a.date.getTime();
                }
                return a.date.getTime() - b.date.getTime();
            });
    }, [sessionGallery, galleryFilter, gallerySort]);
    
    const isBlendFormComplete = images.filter(img => img).length >= 2 && blendMode;
    const isFaceSwapFormComplete = sourceImage && faceRefImage;
    const isInpaintFormComplete = inpaintImage && inpaintMask && inpaintPrompt;

    const styles: { [key: string]: React.CSSProperties } = {
        main: { display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '2rem', gap: '2rem' },
        header: { textAlign: 'center', marginBottom: '1rem' },
        title: { fontFamily: "'Teko', sans-serif", fontSize: '4rem', color: 'var(--primary-color)', textTransform: 'uppercase', letterSpacing: '0.1em' },
        subtitle: { color: 'var(--on-surface-color)', fontSize: '1rem', marginTop: '-0.5rem' },
        container: { display: 'grid', gap: '2rem', width: '100%', maxWidth: '1200px' },
        controls: { background: 'var(--surface-color)', padding: '2rem', borderRadius: '12px', border: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', gap: '1.5rem' },
        tabsContainer: { display: 'flex', borderBottom: '1px solid var(--border-color)', marginBottom: '1rem' },
        tabButton: { padding: '0.75rem 1.5rem', background: 'none', border: 'none', color: 'var(--on-surface-color)', cursor: 'pointer', fontSize: '1rem', fontWeight: 500, borderBottom: '3px solid transparent', transition: 'all 0.3s ease' },
        tabButtonActive: { color: 'var(--primary-color)', borderBottom: '3px solid var(--primary-color)' },
        imageUploads: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))', gap: '1rem' },
        uploadBox: { display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', border: '2px dashed var(--border-color)', borderRadius: '8px', aspectRatio: '1 / 1', textAlign: 'center', cursor: 'pointer', position: 'relative', overflow: 'hidden', transition: 'all 0.3s ease' },
        uploadBoxHover: { borderColor: 'var(--primary-color)', backgroundColor: '#2a2a2a' },
        uploadIcon: { fontSize: '2rem', color: 'var(--on-surface-color)' },
        uploadText: { fontSize: '0.9rem', color: 'var(--on-surface-color)', marginTop: '0.5rem' },
        imagePreview: { width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', top: 0, left: 0 },
        removeButton: { position: 'absolute', top: '5px', right: '5px', background: 'rgba(0,0,0,0.7)', color: 'white', border: 'none', borderRadius: '50%', width: '24px', height: '24px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', zIndex: 10, transition: 'transform 0.2s' },
        addImageButton: { display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px dashed var(--border-color)', borderRadius: '8px', background: 'transparent', color: 'var(--on-surface-color)', fontSize: '3rem', cursor: 'pointer', transition: 'all 0.3s ease', aspectRatio: '1 / 1' },
        sectionTitle: { fontSize: '1.2rem', fontWeight: 500, borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem', marginBottom: '0.5rem' },
        blendModes: { display: 'flex', flexWrap: 'wrap', gap: '0.75rem' },
        blendCard: { padding: '1rem', border: '1px solid var(--border-color)', background: 'var(--background-color)', color: 'var(--on-surface-color)', borderRadius: '8px', cursor: 'pointer', transition: 'all 0.3s ease', flexGrow: 1, flexBasis: 'calc(50% - 0.5rem)', textAlign: 'left' },
        blendCardSelected: { borderColor: 'var(--primary-color)', boxShadow: '0 0 10px var(--primary-color)', background: '#2a2a2a' },
        blendCardTitle: { fontWeight: 'bold', marginBottom: '0.25rem', color: 'var(--primary-color)' },
        blendCardDescription: { fontSize: '0.85rem', color: 'var(--on-surface-color)', lineHeight: 1.4 },
        aspectRatioSelector: { display: 'flex', gap: '0.75rem', flexWrap: 'wrap' },
        aspectRatioButton: { padding: '0.5rem 1rem', border: '1px solid var(--border-color)', background: 'var(--background-color)', color: 'var(--on-surface-color)', borderRadius: '8px', cursor: 'pointer', transition: 'all 0.3s ease' },
        aspectRatioButtonSelected: { borderColor: 'var(--primary-color)', color: 'var(--primary-color)', background: '#2a2a2a' },
        promptInput: { width: '100%', minHeight: '80px', background: 'var(--background-color)', border: '1px solid var(--border-color)', borderRadius: '8px', padding: '0.75rem', color: 'var(--on-surface-color)', fontSize: '1rem', resize: 'vertical' },
        selectInput: { width: '100%', background: 'var(--background-color)', border: '1px solid var(--border-color)', borderRadius: '8px', padding: '0.75rem', color: 'var(--on-surface-color)', fontSize: '1rem' },
        actionButtonsContainer: { display: 'flex', gap: '1rem', marginTop: 'auto' },
        resetButton: { padding: '1rem', fontSize: '1.2rem', fontWeight: 'bold', background: 'var(--surface-color)', color: 'var(--on-surface-color)', border: '1px solid var(--border-color)', borderRadius: '8px', cursor: 'pointer', transition: 'all 0.3s ease' },
        generateButton: { flexGrow: 1, padding: '1rem', fontSize: '1.2rem', fontWeight: 'bold', background: `linear-gradient(45deg, var(--primary-color), var(--secondary-color))`, color: 'var(--background-color)', border: 'none', borderRadius: '8px', cursor: 'pointer', transition: 'all 0.3s ease', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' },
        generateButtonDisabled: { opacity: 0.5, cursor: 'not-allowed' },
        result: { background: 'var(--surface-color)', padding: '2rem', borderRadius: '12px', border: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '500px', position: 'relative' },
        resultActions: { display: 'flex', gap: '1rem', marginTop: '1.5rem' },
        generatedImageContainer: { width: '100%', position: 'relative', borderRadius: '8px', overflow: 'hidden', background: 'var(--background-color)' },
        generatedImage: { position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', objectFit: 'contain' },
        resultThumbnailsContainer: { display: 'flex', gap: '0.5rem', marginTop: '1rem', flexWrap: 'wrap', justifyContent: 'center' },
        resultThumbnail: { width: '80px', height: '80px', objectFit: 'cover', borderRadius: '4px', cursor: 'pointer', border: '2px solid var(--border-color)', transition: 'all 0.2s ease' },
        resultThumbnailSelected: { borderColor: 'var(--primary-color)', transform: 'scale(1.1)' },
        placeholder: { textAlign: 'center', color: 'var(--on-surface-color)' },
        spinner: { border: '4px solid rgba(255, 255, 255, 0.3)', borderRadius: '50%', borderTop: '4px solid var(--primary-color)', width: '50px', height: '50px', animation: 'spin 1s linear infinite' },
        error: { color: 'var(--error-color)', textAlign: 'center' },
        actionButton: { padding: '0.75rem 1.5rem', fontSize: '1rem', fontWeight: 500, borderRadius: '8px', cursor: 'pointer', transition: 'all 0.3s ease', textDecoration: 'none', textAlign: 'center' },
        primaryActionButton: { background: 'var(--primary-color)', color: 'var(--background-color)', border: '1px solid var(--primary-color)' },
        secondaryActionButton: { background: 'var(--surface-color)', color: 'var(--primary-color)', border: '1px solid var(--primary-color)' },
        sessionGallery: { width: '100%', maxWidth: '1200px', background: 'var(--surface-color)', padding: '1.5rem 2rem', borderRadius: '12px', border: '1px solid var(--border-color)' },
        galleryContainer: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(100px, 1fr))', gap: '1rem', padding: '1rem 0' },
        galleryThumbnail: { position: 'relative', width: '100%', paddingBottom: '100%', borderRadius: '8px', overflow: 'hidden', cursor: 'pointer', border: '2px solid var(--border-color)', transition: 'all 0.3s ease' },
        galleryThumbnailImg: { position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', objectFit: 'cover' },
        galleryTooltip: { position: 'absolute', bottom: '110%', left: '50%', transform: 'translateX(-50%)', background: 'rgba(0,0,0,0.8)', color: 'white', padding: '0.5rem', borderRadius: '4px', fontSize: '0.8rem', whiteSpace: 'nowrap', zIndex: 20, pointerEvents: 'none', opacity: 0, transition: 'opacity 0.2s' },
        galleryEditButton: { position: 'absolute', top: '5px', left: '5px', background: 'rgba(0,0,0,0.7)', color: 'white', border: 'none', borderRadius: '50%', width: '24px', height: '24px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10, transition: 'transform 0.2s', fontSize: '0.7rem' },
        galleryFilterContainer: { display: 'flex', gap: '1rem', marginBottom: '1rem', alignItems: 'center' },
        maskingContainer: { position: 'relative', width: '100%', maxWidth: '400px', margin: '0 auto' },
        maskingCanvas: { position: 'absolute', top: 0, left: 0, cursor: 'crosshair', touchAction: 'none' },
        maskControls: { display: 'flex', flexDirection: 'column', gap: '0.75rem', marginTop: '1rem' },
        sliderContainer: { display: 'flex', alignItems: 'center', gap: '1rem' },
        slider: { flexGrow: 1 },
    };
    
    const styleSheet = `
      @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
      @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
      .main-content-container { grid-template-columns: 1fr 1fr; }
      @media (max-width: 900px) { .main-content-container { grid-template-columns: 1fr; } }
      .tab-content { animation: fadeIn 0.5s ease; }
      .gallery-thumbnail:hover .gallery-tooltip { opacity: 1; }
      .gallery-thumbnail:hover .gallery-edit-button { transform: scale(1.1); }
      .action-button:hover, button:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
      .blend-card:hover, .aspect-ratio-button:hover, .gallery-thumbnail:hover { transform: scale(1.03); border-color: var(--primary-color); }
      .remove-button:hover { transform: scale(1.2); }
      select, textarea, button, input { transition: all 0.3s ease; }
    `;

    const getAspectRatioPadding = (ratio: string) => {
        if (!ratio) return '100%';
        const [width, height] = ratio.split(':').map(Number);
        return `${(height / width) * 100}%`;
    };

    const ImageUploader = ({ image, onUpload, onRemove, label }: { image: string | null, onUpload: (e: React.ChangeEvent<HTMLInputElement>) => void, onRemove: () => void, label: string }) => {
        const [isHovered, setIsHovered] = useState(false);
        const uploaderStyle = {...styles.uploadBox, ...(isHovered && !image ? styles.uploadBoxHover : {})};
        return (
            <div style={{ position: 'relative' }}>
                <label style={uploaderStyle} onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
                    <input type="file" accept="image/png, image/jpeg" onChange={onUpload} style={{ display: 'none' }} aria-label={label} />
                    {image ? (
                         <img src={image} alt="Preview" style={styles.imagePreview} />
                    ) : ( <> <span style={styles.uploadIcon}>🖼️</span> <span style={styles.uploadText}>{label}</span> </> )}
                </label>
                {image && <button type="button" style={styles.removeButton} onClick={(e) => {e.preventDefault(); onRemove();}} aria-label={`Remove ${label}`}>X</button>}
            </div>
        );
    };

    const MaskingCanvas = ({ sourceImage, brushSize, onMaskChange, onClear }: { sourceImage: string, brushSize: number, onMaskChange: (mask: string) => void, onClear: () => void }) => {
        const canvasRef = useRef<HTMLCanvasElement>(null);
        const isDrawing = useRef(false);
    
        useEffect(() => {
            const canvas = canvasRef.current;
            const ctx = canvas?.getContext('2d');
            if (!canvas || !ctx) return;
    
            const image = new Image();
            image.src = sourceImage;
            image.onload = () => {
                canvas.width = image.naturalWidth;
                canvas.height = image.naturalHeight;
            };
        }, [sourceImage]);
    
        const getCoords = (e: React.MouseEvent | React.TouchEvent) => {
            const canvas = canvasRef.current;
            if (!canvas) return { x: 0, y: 0 };
            const rect = canvas.getBoundingClientRect();
            let clientX, clientY;
            if ('touches' in e) {
                clientX = e.touches[0].clientX;
                clientY = e.touches[0].clientY;
            } else {
                clientX = e.clientX;
                clientY = e.clientY;
            }
            return {
                x: (clientX - rect.left) * (canvas.width / rect.width),
                y: (clientY - rect.top) * (canvas.height / rect.height)
            };
        };
    
        const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
            e.preventDefault();
            const ctx = canvasRef.current?.getContext('2d');
            if (!ctx) return;
            isDrawing.current = true;
            const { x, y } = getCoords(e);
            ctx.beginPath();
            ctx.moveTo(x, y);
        };
    
        const draw = (e: React.MouseEvent | React.TouchEvent) => {
            e.preventDefault();
            if (!isDrawing.current) return;
            const ctx = canvasRef.current?.getContext('2d');
            if (!ctx) return;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
            ctx.lineWidth = brushSize;
            const { x, y } = getCoords(e);
            ctx.lineTo(x, y);
            ctx.stroke();
        };
    
        const stopDrawing = () => {
            const canvas = canvasRef.current;
            if (!canvas || !isDrawing.current) return;
            isDrawing.current = false;
            canvas.getContext('2d')?.closePath();
            onMaskChange(canvas.toDataURL());
        };
    
        const clearCanvas = () => {
            const canvas = canvasRef.current;
            const ctx = canvas?.getContext('2d');
            if (canvas && ctx) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                onClear();
            }
        };

        return (
            <div style={styles.maskingContainer}>
                <img src={sourceImage} alt="Source for masking" style={{ width: '100%', borderRadius: '8px', pointerEvents: 'none' }} />
                <canvas 
                    ref={canvasRef} 
                    style={{...styles.maskingCanvas, width: '100%', height: '100%'}}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                />
                <div style={styles.maskControls}>
                    <div style={styles.sliderContainer}>
                        <span>Brush Size:</span>
                        <input 
                            type="range" 
                            min="10" 
                            max="100" 
                            value={brushSize} 
                            onChange={e => setBrushSize(Number(e.target.value))} 
                            style={styles.slider}
                            aria-label="Brush size"
                        />
                         <span>{brushSize}</span>
                    </div>
                    <button onClick={clearCanvas} style={{...styles.actionButton, ...styles.secondaryActionButton}}>Clear Mask</button>
                </div>
            </div>
        );
    };

    const BlendControls = () => (
        <>
            <h2 style={styles.sectionTitle}>1. Upload Your Images (2-5)</h2>
            <div style={styles.imageUploads}>
                {images.map((image, index) => ( <ImageUploader key={index} image={image} onUpload={(e) => handleImageUpload(e, index)} onRemove={() => handleRemoveImage(index)} label={`Image ${index + 1}`} /> ))}
                {images.length < 5 && ( <button onClick={handleAddImageSlot} style={styles.addImageButton} aria-label="Add another image slot">+</button> )}
            </div>
            <h2 style={styles.sectionTitle}>2. Choose Blend Style</h2>
            <div style={styles.blendModes}>
                {BLEND_MODES.map(mode => (
                    <div key={mode.name} onClick={() => setBlendMode(mode.name)} style={{...styles.blendCard, ...(blendMode === mode.name ? styles.blendCardSelected : {})}} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && setBlendMode(mode.name)} aria-pressed={blendMode === mode.name}>
                        <h4 style={styles.blendCardTitle}>{mode.name}</h4>
                        <p style={styles.blendCardDescription}>{mode.description}</p>
                    </div>
                ))}
            </div>
            <h2 style={styles.sectionTitle}>3. Add Guidance (Optional)</h2>
            <textarea style={styles.promptInput} placeholder="e.g., in the style of an oil painting, a surreal masterpiece..." value={prompt} onChange={(e) => setPrompt(e.target.value)} aria-label="Additional guidance prompt" />
            <h2 style={styles.sectionTitle}>4. Select Generation Model</h2>
            <select style={styles.selectInput} value={selectedModel} onChange={e => setSelectedModel(e.target.value)} aria-label="Select generation model">
                {GENERATION_MODELS.map(model => ( <option key={model.id} value={model.id}>{model.name}</option> ))}
            </select>
            <h2 style={styles.sectionTitle}>5. Select Aspect Ratio</h2>
            <div style={styles.aspectRatioSelector}>
                {ASPECT_RATIOS.map(ratio => ( <button key={ratio} onClick={() => setAspectRatio(ratio)} style={{...styles.aspectRatioButton, ...(aspectRatio === ratio ? styles.aspectRatioButtonSelected : {})}}> {ratio} </button> ))}
            </div>
            <h2 style={styles.sectionTitle}>6. Number of Images</h2>
             <div style={styles.sliderContainer}>
                <input type="range" min="1" max="4" value={numberOfImages} onChange={e => setNumberOfImages(Number(e.target.value))} style={styles.slider} aria-label="Number of images to generate" />
                <span>{numberOfImages}</span>
            </div>
        </>
    );

    const FaceSwapControls = () => (
        <div style={{display: 'flex', flexDirection: 'column', gap: '1.5rem'}}>
            <h2 style={styles.sectionTitle}>1. Upload Images</h2>
             <p style={{marginTop: '-1rem', marginBottom: '0.5rem', fontSize: '0.9rem', color: 'var(--on-surface-color)'}}>
                Upload a source image and the face you want to swap onto it.
            </p>
            <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem'}}>
                <ImageUploader image={faceRefImage} onUpload={handleFaceRefUpload} onRemove={() => setFaceRefImage(null)} label="Face to Swap" />
                <ImageUploader image={sourceImage} onUpload={handleSourceImageUpload} onRemove={() => setSourceImage(null)} label="Source Image" />
            </div>
            {sourceImage && (
                <div>
                     <h3 style={{...styles.sectionTitle, border: 'none', fontSize: '1rem'}}>2. Mask Area (Optional)</h3>
                     <p style={{marginTop: '-1rem', marginBottom: '0.5rem', fontSize: '0.9rem', color: 'var(--on-surface-color)'}}>Draw a mask on the source image to focus the swap on a specific area.</p>
                     <MaskingCanvas sourceImage={sourceImage} brushSize={brushSize} onMaskChange={setMask} onClear={() => setMask(null)} />
                </div>
            )}
            <h2 style={styles.sectionTitle}>3. Advanced Controls</h2>
             <div style={styles.sliderContainer}>
                <label htmlFor="faceFidelity" style={{flexBasis: '120px'}}>Face Fidelity:</label>
                <input id="faceFidelity" type="range" min="0" max="100" value={faceFidelity} onChange={e => setFaceFidelity(Number(e.target.value))} style={styles.slider} aria-label="Face fidelity percentage" />
                <span>{faceFidelity}%</span>
            </div>
             <div style={styles.sliderContainer}>
                <label htmlFor="colorMatching" style={{flexBasis: '120px'}}>Color Matching:</label>
                <input id="colorMatching" type="range" min="0" max="100" value={colorMatching} onChange={e => setColorMatching(Number(e.target.value))} style={styles.slider} aria-label="Color matching percentage" />
                <span>{colorMatching}%</span>
            </div>
            <h2 style={styles.sectionTitle}>4. Add Guidance (Optional)</h2>
            <textarea style={styles.promptInput} placeholder="e.g., match the expression of the source image, adjust skin tone slightly..." aria-label="Face swap guidance" value={faceSwapPrompt} onChange={(e) => setFaceSwapPrompt(e.target.value)} />
        </div>
    );
    
    const InpaintingControls = () => (
        <div style={{display: 'flex', flexDirection: 'column', gap: '1.5rem'}}>
            <h2 style={styles.sectionTitle}>1. Load Image to Edit</h2>
            {!inpaintImage ? (
                 <ImageUploader image={inpaintImage} onUpload={handleInpaintImageUpload} onRemove={() => setInpaintImage(null)} label="Upload Image" />
            ) : (
                <div>
                     <p style={{marginBottom: '0.5rem', color: 'var(--on-surface-color)'}}>Draw a mask on the area you want to replace.</p>
                     <MaskingCanvas sourceImage={inpaintImage} brushSize={brushSize} onMaskChange={setInpaintMask} onClear={() => setInpaintMask(null)} />
                </div>
            )}
            <h2 style={styles.sectionTitle}>2. Describe Your Edit</h2>
            <textarea style={styles.promptInput} placeholder="e.g., add a superhero mask, change hair to blue, remove the person..." aria-label="Inpainting prompt" value={inpaintPrompt} onChange={(e) => setInpaintPrompt(e.target.value)} />
            <h2 style={styles.sectionTitle}>3. Advanced Controls</h2>
             <div style={styles.sliderContainer}>
                <label htmlFor="inpaintCreativity" style={{flexBasis: '120px'}}>Creativity:</label>
                <input id="inpaintCreativity" type="range" min="0" max="100" value={inpaintCreativity} onChange={e => setInpaintCreativity(Number(e.target.value))} style={styles.slider} aria-label="Inpainting creativity percentage" />
                <span>{inpaintCreativity}%</span>
            </div>
        </div>
    );

    return (
        <main style={styles.main}>
            <style>{styleSheet}</style>
            <header style={styles.header}>
                <h1 style={styles.title}>AI Image Fusion</h1>
                <p style={styles.subtitle}>by Massive Magnetics</p>
            </header>

            <div className="main-content-container" style={styles.container}>
                <div style={styles.controls}>
                    <div style={styles.tabsContainer}>
                        <button style={{...styles.tabButton, ...(activeTab === 'blend' ? styles.tabButtonActive : {})}} onClick={() => setActiveTab('blend')}>Image Blending</button>
                        <button style={{...styles.tabButton, ...(activeTab === 'swap' ? styles.tabButtonActive : {})}} onClick={() => setActiveTab('swap')}>Face Swap</button>
                        <button style={{...styles.tabButton, ...(activeTab === 'inpaint' ? styles.tabButtonActive : {})}} onClick={() => setActiveTab('inpaint')}>Inpainting</button>
                    </div>

                    <div key={activeTab} className="tab-content">
                       {activeTab === 'blend' && <BlendControls />}
                       {activeTab === 'swap' && <FaceSwapControls />}
                       {activeTab === 'inpaint' && <InpaintingControls />}
                    </div>

                    <div style={styles.actionButtonsContainer}>
                         <button style={styles.resetButton} className="action-button" onClick={handleReset}>Reset</button>
                         <button 
                            style={{
                                ...styles.generateButton, 
                                ...((loading ||
                                    (activeTab === 'blend' && !isBlendFormComplete) || 
                                    (activeTab === 'swap' && !isFaceSwapFormComplete) ||
                                    (activeTab === 'inpaint' && !isInpaintFormComplete)
                                ) ? styles.generateButtonDisabled : {})
                            }} 
                            onClick={handleGenerate} 
                            disabled={
                                loading ||
                                (activeTab === 'blend' && !isBlendFormComplete) || 
                                (activeTab === 'swap' && !isFaceSwapFormComplete) ||
                                (activeTab === 'inpaint' && !isInpaintFormComplete)
                            }
                         >
                            {loading && <div style={{...styles.spinner, width: '20px', height: '20px', borderTopColor: 'var(--background-color)', borderWidth: '2px'}}></div>}
                            Generate
                        </button>
                    </div>
                </div>

                <div style={styles.result}>
                    {loading && (
                        <div style={styles.placeholder}>
                            <div style={styles.spinner}></div>
                            <p style={{marginTop: '1rem'}}>{loadingMessage}</p>
                        </div>
                    )}
                    {error && !loading && <p style={styles.error}>{error}</p>}
                    {!loading && !error && generatedImage && (
                        <>
                          <div style={{...styles.generatedImageContainer, paddingTop: getAspectRatioPadding(activeTab === 'blend' ? aspectRatio : '1:1')}}>
                              <img src={generatedImage} alt="Generated result" style={styles.generatedImage}/>
                          </div>
                           {generatedImages.length > 1 && (
                            <div style={styles.resultThumbnailsContainer}>
                                {generatedImages.map((img, index) => (
                                    <img 
                                        key={index} 
                                        src={img} 
                                        alt={`Result ${index + 1}`}
                                        style={{...styles.resultThumbnail, ...(img === generatedImage ? styles.resultThumbnailSelected : {})}}
                                        onClick={() => {
                                            setGeneratedImage(img);
                                            setGeneratedImageMetadata(null);
                                        }}
                                    />
                                ))}
                            </div>
                           )}
                           {generatedImageMetadata ? (
                                <div style={{textAlign: 'center', margin: '1rem 0', animation: 'fadeIn 0.5s ease'}}>
                                    <p><strong>Name:</strong> {generatedImageMetadata.name}</p>
                                    <p><strong>Tags:</strong> {generatedImageMetadata.tags.join(', ')}</p>
                                </div>
                            ) : (
                                <p style={{textAlign: 'center', margin: '1rem 0', color: 'var(--on-surface-color)', fontStyle: 'italic'}}>
                                    Generate metadata to name and save your creation.
                                </p>
                            )}
                          <div style={styles.resultActions}>
                            {!generatedImageMetadata && (
                                <button onClick={handleGenerateMetadata} style={{...styles.actionButton, ...styles.secondaryActionButton}} className="action-button" disabled={isMetadataLoading}>
                                    {isMetadataLoading ? 'Analyzing...' : 'Generate Metadata'}
                                </button>
                            )}
                            <button onClick={handleSaveToSession} style={{...styles.actionButton, ...styles.secondaryActionButton}} className="action-button" disabled={!generatedImageMetadata}> Save to Session </button>
                            <a href={generatedImage} download={`${generatedImageMetadata?.name || 'generated-image'}.jpg`} style={{...styles.actionButton, ...styles.primaryActionButton}} className="action-button"> Download Image </a>
                          </div>
                        </>
                    )}
                    {!loading && !error && !generatedImage && (
                        <div style={styles.placeholder}>
                            <span style={{fontSize: '3rem', display: 'block', marginBottom: '1rem'}}>✨</span>
                            <h3 style={{fontSize: '1.2rem'}}>Your masterpiece will appear here</h3>
                            <p>Complete the steps on the left to begin.</p>
                        </div>
                    )}
                </div>
            </div>
            
            {sessionGallery.length > 0 && (
                <div style={styles.sessionGallery}>
                    <div style={{...styles.sectionTitle, display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                        <h2>Session Gallery</h2>
                        <div style={styles.galleryFilterContainer}>
                            <select value={galleryFilter} onChange={e => setGalleryFilter(e.target.value)} style={{...styles.selectInput, width: 'auto'}} aria-label="Filter by generation type">
                                <option value="all">All Types</option>
                                <option value="blend">Blends</option>
                                <option value="swap">Swaps</option>
                                <option value="inpaint">Inpaints</option>
                            </select>
                            <button onClick={() => setGallerySort(s => s === 'newest' ? 'oldest' : 'newest')} style={{...styles.actionButton, ...styles.secondaryActionButton}}>{gallerySort === 'newest' ? 'Sort Oldest' : 'Sort Newest'}</button>
                        </div>
                    </div>
                    <div style={styles.galleryContainer}>
                        {filteredAndSortedGallery.map((item, index) => (
                            <div key={item.src + index} style={styles.galleryThumbnail} className="gallery-thumbnail">
                                <img src={item.src} alt={item.name} style={styles.galleryThumbnailImg} onClick={() => {setGeneratedImage(item.src); setAspectRatio(item.aspectRatio); setGeneratedImages([item.src])}} />
                                <div style={styles.galleryTooltip} className="gallery-tooltip">{item.name}</div>
                                <button style={styles.galleryEditButton} className="gallery-edit-button" onClick={() => handleLoadToInpainting(item.src)} title="Edit in Inpainting Tab">✎</button>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </main>
    );
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);